# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.14.0](https://github.com/AugustoPeralta/yarn-workspaces/compare/v1.13.0...v1.14.0) (2021-04-08)


### Features

* adding zipping ([07fad65](https://github.com/AugustoPeralta/yarn-workspaces/commit/07fad651a0e81e16f22fb5378466a433188c93b5))






# [1.12.0](https://github.com/AugustoPeralta/yarn-workspaces/compare/v1.11.0...v1.12.0) (2021-04-07)


### Features

* adding zipping ([d740566](https://github.com/AugustoPeralta/yarn-workspaces/commit/d740566f336bef7d2299fadece35b5e30bb9efb9))






# [1.10.0](https://github.com/AugustoPeralta/yarn-workspaces/compare/v1.9.0...v1.10.0) (2021-04-07)

**Note:** Version bump only for package @gskTest/common






# [1.9.0](https://github.com/AugustoPeralta/yarn-workspaces/compare/v1.8.0...v1.9.0) (2021-04-07)


### Features

* last ([af549d6](https://github.com/AugustoPeralta/yarn-workspaces/commit/af549d68c2b22cf126633be1e71243d1f9f61c24))
* last change ([e5236ed](https://github.com/AugustoPeralta/yarn-workspaces/commit/e5236ed9411a3e841b3f86dd97540d983cbad423))
* lastone ([3293d0e](https://github.com/AugustoPeralta/yarn-workspaces/commit/3293d0eb2f5746d5ed5979e9839fabb7a7a073ff))
* lastone ([bff16e6](https://github.com/AugustoPeralta/yarn-workspaces/commit/bff16e6ab6bff34314a50b340614bace1e353e6a))
* lastone ([f3c97fc](https://github.com/AugustoPeralta/yarn-workspaces/commit/f3c97fcabecadd518ed355218602acdfc3d87d0d))
