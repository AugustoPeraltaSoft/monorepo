module.exports = () => {
  console.log("hello from @gskTest/common");
};

