module.exports = () => {
  // TODO: say hi, again and again and more
    console.log("BEHOLD MY FRONTEND PACKAGE!");
    console.log("hello peoplee, from @gskTest/common");
    console.log("hello from @gskTest/common again");
};

