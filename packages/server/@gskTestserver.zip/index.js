const commonFunction = require("@gskTest/common");
 // TODO: say hi, again and again and more

commonFunction();
